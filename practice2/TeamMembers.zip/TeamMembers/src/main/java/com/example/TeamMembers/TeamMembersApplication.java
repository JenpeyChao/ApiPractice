package com.example.TeamMembers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeamMembersApplication {

	public static void main(String[] args) {
		SpringApplication.run(TeamMembersApplication.class, args);
	}

}
